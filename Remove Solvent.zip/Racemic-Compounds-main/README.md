# Racemic-Compounds
I've created this repo to save some codes to deal with racemic compounds.
</br>
Here are their descriptions:
</br></br>
1_coord_distinguish.ipynb:
</br>
Distinguish between the main molecules and the solvent molecule in a chemical system.</br></br>
2_distance.ipynb:
</br>
Calculate the distance between a line and a point or between two lines.</br></br>
