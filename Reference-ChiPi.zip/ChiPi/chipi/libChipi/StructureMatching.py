import numpy as np
from enum import Enum

ROT = 0
NAME = 2
TRANS = 1

NEG_COMP = 0

START_APPROX = 0

MISSED_PARAM = [0, 0.05, 0.1, 0.15, 0.2]


class Struct():

  rotation = None
  translation = None
  name = None

  def __init__(self, rot, trans, name):
    self.rotation = rot
    self.translation = trans
    self.name = name

class StructureMatching():

  approxiation = 0

  # 0

  listMatZeroNeg =  [
                      Struct( np.array([[1, 0, 0],
                                        [0, 1, 0],
                                        [0, 0, 1]]),
                              np.array([0, 0, 0]),
                              "identity"),
                      Struct( np.array([[1, 0, 0],
                                        [0, 1, 0],
                                        [0, 0, 1]]),
                              np.array([-0.978, -0.22, -1.530]),
                              "translational type")
                    ]


  #1
  
  listMatOneNeg =   [
                      Struct( np.array([[-1, 0, 0],
                                        [ 0, 1, 0],
                                        [ 0, 0, 1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "glide plane A"),
                      Struct( np.array([[1,  0, 0],
                                        [0, -1, 0],
                                        [0,  0, 1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "glide plane B"),
                      Struct( np.array([[1, 0,  0],
                                        [0, 1,  0],
                                        [0, 0, -1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "glide plane C"),
                      Struct(np.array([[-1, 0, 0],
                                      [ 0, 1, 0],
                                      [ 0, 0, 1]]),
                            np.array([0.478, -0.720, -1.030]),
                            "screw axis type A"),

                      Struct( np.array([[1,  0, 0],
                                        [0, -1, 0],
                                        [0,  0, 1]]),
                              np.array([-0.478, 0.720, -1.030]),
                              "screw axis type B"),
                      Struct( np.array([[1, 0,  0],
                                        [0, 1,  0],
                                        [0, 0, -1]]),
                              np.array([-0.478, -0.720, 1.030]),
                              "screw axis type C")
                    ]

  #2

  listMatTwoNeg =   [
                      Struct( np.array([[1,  0,  0],
                                        [0, -1,  0],
                                        [0,  0, -1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "screw axis A"),
                      Struct( np.array([[-1, 0,  0],
                                        [ 0, 1,  0],
                                        [ 0, 0, -1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "screw axis B"),
                      Struct( np.array([[-1,  0, 0],
                                        [ 0, -1, 0],
                                        [ 0,  0, 1]]),
                              np.array([1/2, 1/2, 1/2]),
                              "screw axis C"),
                      
                      Struct( np.array([[1, 0,  0],
                                        [0, -1, 0],
                                        [0, 0, -1]]),
                              np.array([-0.478, 0.720, 1.030]),
                              "rotational type A"),
                      
                      Struct( np.array([[-1, 0,  0],
                                        [ 0, 1,  0],
                                        [ 0, 0, -1]]),
                              np.array([0.478, -0.720, 1.030]),
                              "rotational type B"),
                      
                      Struct( np.array([[-1,  0, 0],
                                        [ 0, -1, 0],
                                        [ 0,  0, 1]]),
                              np.array([0.478, 0.720, -1.030]),
                              "rotational type C")
                    ]
  
  #3

  listMatThreeNeg = [
                      
                      Struct( np.array([[-1,  0,  0],
                                        [ 0, -1,  0],
                                        [ 0,  0, -1]]),
                              np.array([0, 0, 0]),
                              "inversion"),
                      
                      Struct( np.array([[-1,  0,  0],
                                        [ 0, -1,  0],
                                        [ 0,  0, -1]]),
                              np.array([0.978, 0.22, 1.530]),
                              "inversion type")
                    ]

  noMatFound = Struct(None,
                      None,
                      "No match found")

  listAllMat = [listMatZeroNeg, listMatOneNeg, listMatTwoNeg, listMatThreeNeg]


  #### setApproxiation
  # Change le pourcentage d'erreur utilisé par l'instance StructureMatching
  #
  # @param indice : entier correspond a l'indice du Tableau MISSED_PARAM
  
  def setApproxiation(self, indice):
    if (0 < indice < 5): 
      self.approxiation = indice


  #### compareMat
  # Compare deux matrices entre elles avec un pourcentage d'erreur qui est de approximation.
  # Renvoie le taux de conformité si mat est conforme a types, None sinon
  #
  #   @param mat : tableau a comparé, doit avoir le même nombre colonne et de ligne que types
  #   @param types : tableau a comparé, doit avoir le même nombre colonne et de ligne que mat

  def compareMat(self, mat, types):
    
    r = 0

    for i in range(0, len(mat)):
      rv = self.compareArray(mat[i], types[i])
      if (not rv):
        return None
      r += rv
    
    return r / len(mat[0])


  #### compareMat
  # Compare deux tableau d'une seule dimention entre eux avec un pourcentage d'erreur qui est 
  #   de approximation.
  # Renvoie le taux de conformité si array est conforme a types, None sinon.
  #
  #   @param array : tableau a comparé, doit avoir le même nombre colonne que types
  #   @param types : tableau a comparé, doit avoir le même nombre colonne que array

  def compareArray(self, array, types):
    
    r = 0

    for j in range(0, len(array)):
      if np.isclose(array[j], types[j], atol=MISSED_PARAM[self.approxiation]) == False:
        return None
      elif (types[j] == 0): 
        r += (1 - (array[j] ** 2))
        continue
      else: 
        r += array[j] / types[j]
    
    return r / len(array)


  #### compareMat
  # Renvoie le nombre de chiffres negatifs sur la diagonal principale de mat
  #
  #   @param mat : matrice dont les chiffres vont être extrait

  def getNbNegNumber(self, mat):

    r = 0

    for i in range(0, len(mat)):
      r += 1 if (mat[i][i] < NEG_COMP) else 0
    
    return r


  #### matchStruct
  # Recherche parmis toutes les matrice défini si il y a une correspondance avec mat. 
  # Renvoie la matrice la plus similaire si elle existe, None sinon
  #
  #   @param array : tableau a comparé, doit avoir le même nombre colonne que types
  #   @param types : tableau a comparé, doit avoir le même nombre colonne que array

  def matchStruct(self, info):

    mat = Struct(
            np.asarray(info.rotation),
            np.asarray(info.translation),
            "unknow")

    res = 1.
    l = self.listAllMat[self.getNbNegNumber(mat.rotation)].copy()
    resArray = np.array([[x for x in MISSED_PARAM], [self.noMatFound for i in range(0, len(MISSED_PARAM))]])
    self.setApproxiation(MISSED_PARAM[START_APPROX])

    for cpt in range(0, len(MISSED_PARAM)):

      tempRes = []
      
      self.setApproxiation(cpt)
      for i in range(0, len(l)):
        
        rcmp = self.compareMat(mat.rotation, l[i].rotation)

        if rcmp and (rcmp <= res):
            res = rcmp
            tempRes.append(l[i])

      if tempRes:
        for i in tempRes : 
          l.remove(i)

      else :
        tempRes.append(self.noMatFound)

      resArray[1][cpt] = tempRes

      # res = 1.
      # defaultMat = None
      # returnValue = None

      # for j in range(0, len(ind)):
      #   if (self.compareArray(np.array([0, 0, 0]), ind[j][TRANS]) == 1):
      #     defaultMat = ind[j][TRANS]
      #     continue
      #   rcmp = self.compareArray(mat.transition, ind[j][TRANS])
      #   if rcmp and (rcmp <= res):
      #     res = rcmp
      #     returnValue = ind[j]
        
      # return returnValue if returnValue else (
      #     defaultMat if defaultMat else self.noMatFound
      #     )

    return [getListOfStructToStr(resArray[1][i]) for i in range(0, len(resArray[1]))]

  def getApproxArray(self):
    return MISSED_PARAM

def getListOfStructToStr(l) :
  s = ""
  for i in range(0, len(l)) :
    s += l[i].name + (';' if i != len(l) -1 else "")
  return s
####################### TEST
def test(): 
  r = Struct( np.array([[0.99,  0,  0],
                          [0, -1,  0],
                          [0,  0, -1]]),
              np.array([1/2, 1/2, 1/2]),
              "unknow")

  s = StructureMatching()
  print("\n________________TEST 1\n")
  print(s.matchStruct(r) if s.matchStruct(r) else "a")

# test()
