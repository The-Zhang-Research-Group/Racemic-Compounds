#!/usr/bin/env python
#
# A part of this script comes from the Cambridge Crystallographic Data Centre
# This script can be used for any purpose without limitation subject to the
# conditions at http://www.ccdc.cam.ac.uk/Community/Pages/Licences/v2.aspx
#
# This permission notice and the following statement of attribution must be
# included in all copies or substantial portions of this script.
#
#ChiPi can be used for any purpose and is working with python 2 and the v2.3 of the CCDC Python API 
#
#
#
#Disclaimer: part of the code are just attempt for future implementations, therefore all functionnalities are not used
#
#
#For any information, please contact: simon.clevers@gmail.com
#
#Further version of the code will be updated and available here: https://labsms.univ-rouen.fr/en/content/chipi
#
'''
Provide information on a set of structures in the CSD.

This script takes as input a gcd file (a text file with CSD refcodes) and
writes out the in csv format information about the chirality of the crystal (achiral, chiral, 
racemic, scalemic, meso,diast). It also returns the molecular point group (only for chiral molecule)
and performs overlay comparison between each molecules in structure having Z'>1
 

'''
from __future__ import division, absolute_import, print_function
#import spglib
import string
import six
import sys
import os
import csv
import html
import argparse
import codecs
import time
import timeit
import itertools
from itertools import chain, combinations
import signal
import numpy as np
from numpy import newaxis
from numpy import *
from numpy import array
from ccdc.io import EntryReader, CrystalReader
from ccdc import io
from ccdc.descriptors import MolecularDescriptors as md, GeometricDescriptors as gd
from ccdc.conformer import MoleculeMinimiser as mm
from ast import literal_eval as make_tuple
from  itertools import chain
import statistics
 

class TimeoutException(Exception):#create a new exception 
    pass

class Writer(object):
    def __init__(self, infile, out, format='csv'):
        try:
            self.rdr = EntryReader(infile, format='identifiers')
        except RuntimeError:
            print('Failed to read input file %s!' % infile)
            exit(1)

        self.out = out
        getattr(self, format + '_header')()
        for e in self.rdr:
            getattr(self, format + '_line')(e)
                                               
        getattr(self, format + '_footer')()
    
    def csv_header(self):
        data = ','.join([
            'Refcode',
            'Class',
            'Note',
            'Kryptoracemic?',
            'Diast?',
            'Space Gp. Symbol',
            'Space Gp. Number',
            'Is Sohncke?',
            'Has Disorder?',          
            'R-factor',
            'Number of chiral resd',
            'Number of chiral families',
            'Number of chiral center',
            'Chiral Atom Symb',
            'Number of Carbon Chiral Atom',
            'Number of Chiral Center having H',
            'R',
            'S',
            'M',
            'Number and type of chiral configuration',
            'Number of chiral configuration',
            'Number of molecule in Family',
            'AU_chirality',
            'point_group_of_chiral_mol',
            'Unique Chemical Units',
            'Z Prime',
            'Z Value',
            'Note1',
            'Note2',
            'Note3',
            'Note4-H assign',
            'a',
            'b',
            'c',
            'Alpha',
            'Beta',
            'Gamma',
            'Cell Volume',
            'Calc. Density',
            'formula',
            'Compound Name',
            'Study Temp.',
            'pressure',
            'melting_point',
            'color',
            'polymorph',
            'phase_transitions',
            'recrystallisation_solvent',
            'remarks',
            'authors_comma_delimited',
            'volume',
            'page',
            'journal',
            'Publication Year',
            'doi',     
            'Time (in seconds)',
            # 'rmsd (mean, std, min max value)/chiral family',
            # 'Tanimoto  (mean, std, min, and max value)/chiral family',
            # 'rmsd_same_chirality(mean, std, min, and max value)/chiral family',
            # 'Tanimoto _same_chirality, std, min, and max value)/chiral family',
            # 'rmsd_Not_same_chirality (mean, std, min, and max value)/chiral family',
            # 'Tanimoto_Not_same_chirality (mean, std, min, and max value)/chiral family',
            
                    ])
        self.out.write(str(data))
        self.out.write('\n')

    def csv_footer(self):
        pass
 
    def csv_line(self, e):
        cpl_chirality=['Not']
        start_time = time.time()
        total_time=0
        Fail=False
        H_added=False
        formal_charge=False
        H_count=0
        C_count=0
        undefined=0
        warning="error"
        warningb="NA"
        warningc="NA"
        warningd="NA"
        krypto="NO"
        diast="NO"
        AU='ERROR_not_treated'
        AU_x="error"
        AU_1="error"
        final="error"
        test="test"
        crystal=e.crystal
        mol=e.molecule        
        chiral_point_group=['C1', 'C2', 'C3','D2','D3',[],'pg']
        cmax=len(mol.components)#calculate the number of residue in the AU
        Rcomp=np.array([],np.int)#to store the number of R atom in each residue
        Scomp=np.array([],np.int)#to store the number of S atom in each residue
        Mcomp=np.array([],np.int)#to store the number of M atom in each residue
        mol_atom_link=[0 for i in range(cmax)]
        mol_in_component=[0 for i in range(cmax)]
        natom=['n' for i in range(cmax)] #number of atoms in each residue
        nformula=['n' for i in range(cmax)]
        mol_atom_chirality=[0 for i in range(cmax)]
        atom_identical_not_same_chirality=[]
        atom_identical_same_chirality=[]
        Elem=[]#in output this variable refers to atomic symbol(s) of chiral centers in the structure      
        compo=mol.components
        component=[[] for i in range(cmax)]
        component_inv=[[] for i in range(cmax)]
        #inverted_mol = crystal.symmetric_molecule('-x,-y,-z', (0, 0, 0), force=True)
        #print(inverted_mol)
        meso_check=[False for i in range(cmax)]
        try:
            SG=crystal.spacegroup_number_and_setting[0]# store the SG number
        except (RuntimeError,IndexError) as exp:
            SG="Database Error"
        inverted_mol = crystal.symmetric_molecule('-x,-y,-z', (0, 0, 0), force=True) # creation of the inverted molecules    
        for x, (comp,comp_inv) in enumerate(zip(mol.components,inverted_mol.components)):             
            component[x]=comp     
            #print(x,comp.molecular_weight)
            #Perform a tidy up of the structure adding the unknown bond types and missign H atoms
            #this operation is perfomed for each component - 
            #- it means that if this operation fails for one, the calculation is not stop. 
            #in this version if Fails raised the structure is classified as ERROR
            #In future version a tentative to assign chirality of such structures will be attempt 

            try: 
                comp.assign_bond_types('Unknown')#assign unknown bond
                comp.add_hydrogens()#add hydrogen atom 
                comp.normalise_atom_order()#normalise the atom order
                comp.normalise_labels()#verifies if each label is unique
                comp_inv.assign_bond_types('Unknown')#assign unknown bond
                comp_inv.add_hydrogens()#add hydrogen atom 
                comp_inv.normalise_atom_order()#normalise the atom order
                comp_inv.normalise_labels()#verifies if each label is unique
                component[x]=comp
                component_inv[x]=comp_inv

            except (IndexError, RuntimeError) as exc:
                warningd='H assigment Error'
                Fail=True
  
            natom[x]=len(comp.atoms)
            temp=[]
            temp_inv=[]
            r=0
            s=0
            m=0
            resd=0
            ChiAtom=[]
            atom_chirality=[]
            atom_chirality_inv=[]
            
           #loop to count the number and determine the chirality of each atoms in each molecule
            for i,(atom,atom_inv) in enumerate(zip(comp.atoms, comp_inv.atoms)):                            
                neighbours=atom.neighbours
                neighbours_inv=atom_inv.neighbours
                at_sym_bond=[]
                at_sym_bond_inv=[]
  
                for atom_n,atom_n_inv in zip(neighbours,neighbours_inv):#also save neighbouring atoms of each atom
                    at_sym_bond.append(atom_n.atomic_symbol)
                    at_sym_bond_inv.append(atom_n_inv.atomic_symbol)
                listn=[str(atom.atomic_symbol), str(at_sym_bond)]
                listn_inv=[str(atom.atomic_symbol), str(at_sym_bond)]
                temp.append(listn)
                temp_inv.append(listn_inv)
                if atom.is_chiral:
                    if 'H' in atom_n.atomic_symbol:
                        H_count+=1#count the number of chiral atom having a H atom as substituent
                    if 'C'==atom.atomic_symbol:
                        C_count+=1#count the number of chiral carbon atoms
                    atom_chirality.append((str(atom.label),atom.chirality))
                    Elem.append(str(atom.atomic_symbol)) #keep the chiral atom symbol element in memory
                    #print(atom.label,atom.chirality)
                    if atom.chirality == 'R':
                        r+=1   
                    elif atom.chirality == 'S':
                        s+=1        
                    elif atom.chirality == 'Mixed':
                        m+=1
                if atom_inv.is_chiral:
                    atom_chirality_inv.append((str(atom_inv.label),atom_inv.chirality))
                
                #set the charge of each atom to 0 - it is used to then generate same SMILES for molecule with different ionic charge      
                if atom.formal_charge !=0:
                    atom.formal_charge=0
                    formal_charge=True
                 #print(atom_chirality_inv)
                test=list(reversed(atom_chirality_inv))
                 #print(test)
                for a,b in zip(atom_chirality_inv,atom_chirality):
                    #print(a,b)
                    if a[1]==b[1]:
                        meso_check[x]=True

            # after setting formal_charge to zero, we reassign atom bond type and add hydrogens for each components
            if formal_charge:#if flag true, tentative to retry bond type and H-it do not change chirality bacause it was determined before
                try:
                    comp.assign_bond_types('Unknown')
                    comp.add_hydrogens()
                except (IndexError, RuntimeError) as exc:
                    warningc='Could not process structure'
                    Fail=True


            nformula[x]=comp.smiles #the SMILES of the component is save
            mol_atom_chirality[x]=atom_chirality #contains list of chiral atoms with symbol and absolute configuration 
            mol_atom_link[x]=[nformula[x], natom[x], temp] #list containing the SMILES string, the number of atom in the component, and for each atom in the component its the connected atoms 
            mol_in_component[x]=[nformula[x], natom[x], temp, atom_chirality,meso_check[x]]# same list than mol_atom_link completed with a list of chiral atom and absolut configuration in the component
            Rcomp=np.append(Rcomp,r)#save the number of R atoms for each component 
            Scomp=np.append(Scomp,s)#save the number of S atoms for each component 
            Mcomp=np.append(Mcomp,m)#save the number of M atoms for each component 
            

        compo=mol.components
        #variable calculations for the next    
        SumR=sum(Rcomp)#save the total number of R atoms in the structure 
        SumS=sum(Scomp)#save the total number of S atoms in the structure 
        SumM=sum(Mcomp)#save the total number of M atoms in the structure   
        chiral_atom_N=sum(SumR+SumS)#number of chiral centers except M 
        count_nonzero_R=np.count_nonzero(Rcomp)#count the number of molecule having R atom
        count_nonzero_S=np.count_nonzero(Scomp)#count the number of molecul having S atom
        pos_nonzero_R=np.nonzero(Rcomp)
        pos_nonzero_S=np.nonzero(Scomp)
        pos=np.unique(np.concatenate([pos_nonzero_R[0],pos_nonzero_S[0]]))#it save the molecular index chiral molecules
        chiral_mol_N=len(pos)#determine the number of chiral molecules in the structure 
        pos_comb=len(list(itertools.combinations(pos,2)))
        Ntot=set(nformula)
        N_form_chi=[nformula[x] for x in pos]#formula associated to each chiral residue
        pos_formula=[(x, nformula[x]) for x in pos]
        Nc=len(sorted(list(set(N_form_chi))))#number of different different chiral chemicals
        meso_check_c=[meso_check[x] for x in pos]
        
###################################################################
        point_group=['pg'for x in range(Nc)]
        point_group_of_chiral_mol=[]
        #point_group_for_achiral_mol=[]#not yet implemented
        #note_for_achiral_mol=[]
        note_for_chiral_mol=[]
        cpl_not_same_chirality=['NA' for x in range(Nc)]
        cpl_same_chirality=['NA' for x in range(Nc)]
        comparison=[]
        temp_mol_identical=[]
        temp_mol_not_identical=[]
        temp_mol_identical_same_chirality=[]
        temp_mol_identical_not_same_chirality=[]
        temp_comparison=[]
        mol_identical=[[] for x in range(Nc)] #to save pair of molecules identical in term of atom connectivity
        mol_not_identical=[[] for x in range(Nc)]
        mol_identical_same_chirality=[[] for x in range(Nc)] #to save pair of molecules having the same chirality
        mol_identical_not_same_chirality=[[] for x in range(Nc)] #to save pair of molecules having the different chirality
        mol_identical_couples_N=[[] for x in range(Nc)] 
        mol_same_chirality_couples_N=[[] for x in range(Nc)]
        mol_not_same_chirality_couples_N=[[] for x in range(Nc)]
        mol_not_identical_couples_N=[[] for x in range(Nc)]
        chi_type=[0 for x in range(Nc)]
        chi_type_N=[0 for x in range(Nc)]
        chi_type_x=[[] for x in range(Nc)]
        chi_type_transformer=[0 for x in range(Nc)]
        couple_chirality_N=[0 for x in range(Nc)]
        chi_number=[0 for x in range(Nc)]
        AU_x=['AU_x-error' for x in range(Nc)]#to store the chirality relationship between each chiral family 
        store=[[] for x in range(Nc)]
        couple_chirality=[0 for x in range(Nc)]
        #variables for rmsd comparison
        rmsd=[[] for x in range(Nc)]
        rmsd_same_chirality=[[] for x in range(Nc)]
        rmsd_not_same_chirality=[[] for x in range(Nc)]
        tanimoto_same_chirality=[[] for x in range(Nc)]
        tanimoto_not_same_chirality=[[] for x in range(Nc)]
        rmsd_with_inversion=[[] for x in range(Nc)]
        rmsd_deviation=[[] for x in range(Nc)]
        tanimoto=[[] for x in range(Nc)]
        tanimoto_with_inversion=[[] for x in range(Nc)]
#################################################################################################################
  
        if Fail:#true if a problem occured during bond type assignment and adding H 
                final="ERROR due to fail"
                AU_x=['AU_x-error']
                
        else:#no problem during the bond assignement or smiles modification 
        
            if chiral_mol_N==0:#conditions for achiral AU -- No Chiral centre in the structure
                AU="achiral"
                warning="NA"
                final="ACHIRAL"
                Elem=['No Chiral atom']
    
            else:#true if there is at least one chiral atom in the structure -->chiral_atom_N!=0
                if SumM!=0:#if the structure contains a Miwed type atom, the structure will not be treated
                    #the structure could also contain R or S atom, for the moment it not treated    
                    warning="contains "+str(sum(Mcomp))+" mixed chiral(s) atom(s)"
                    AU_x=['Mixed']
                        
                elif SumM== 0:#the structure does not contain any M type atom
                    
                    #the following fo loop will scan for each chiral chemical the nature of their relationship
                    for m,Fx in enumerate(set(N_form_chi)):
                        
                        
                        chi_number[m]=N_form_chi.count(Fx)#determine the number molecule having identical atom connectivity 
                        #Note that trial to do this operation using atom connectivity was performed
                        #But the cannonical atom reordering by the function .normalise_atom_order() creates too much discrepencies
                        #in the atom order of neighbours resulting in a too large set of erroneous  molecular mismatch
                        
                        #determine for a chemical the couples with same chirality and not same chiraity
                        tchi=[]
                        temp_chi=[]
                        #print("pos",pos)
                        if chi_number[m]==1:#true if this chemical family contains only one molecule with at least one R or one S atom                        
                            rmsd_with_inversion[m]=[-1] #value -1 means that the caluculation is not possible
                            tanimoto_with_inversion[m]=[-1]
                            
                            for i in pos:
                                chi_a=mol_in_component[i][3]
                                Fa=mol_in_component[i][0]
                                if Fa==Fx:
                                    for c in chi_a:
                                        temp_chi.append(c[1])
                                    tchi.append(temp_chi)  
                                    tchi=[''.join(x) for x in tchi]
                                    chi_type[m]=tchi
                                    chi_type_N[m]=len(list(set(chi_type[m])))
                                    for ichi,elem in enumerate(set(chi_type[m])):
                                        #print("ichi",ichi, elem)
                                        chi_type_x[m].append((tchi.count(elem),elem))
                                    
                                    
                                    #Point group determination of the set of same molecule base on one of them     
                                    compo[pos[0]].remove_hydrogens()
                                    N_point_group=len(compo[pos[0]].atoms)
                                   
                                    if 3<N_point_group<125:
                                        tempo=md.point_group_analysis(compo[pos[0]])
                                        #print("tempo",tempo)
                                        point_group[m]=str(tempo[1])
                                        #print(m,"point_group",point_group[m])
                                        point_group_of_chiral_mol.append(str(point_group[m]))
                                        #print(i,"point_group_of_chiral_mol",point_group_of_chiral_mol)
                                        note_for_chiral_mol.append(str(tempo[2]))              
                                    else:
                                        warningc="Partially treated"                            
                                    
                                    if SumR+SumS>=2:
                                        #print("point_group_of_chiral_mol",point_group_of_chiral_mol)
                                        if point_group[m] not in chiral_point_group:
                                            AU_x[m]="MESO"
                                            warning="Condition 2"
                                        else:
                                            AU_x[m]="chiral" #the AU is necessaty chiral
                                            warning=("W1_enantiopure AU")                            
                                    else: 
                                        if point_group[m] not in chiral_point_group and crystal.z_prime<1:
                                            AU_x[m]="MESO"
                                        else:
                                            AU_x[m]="chiral" #the AU is necessity chiral
                                            warning=("W2_enantiopure AU")
                        else: #true if this chemical family contain more than one molecule in th AU       
                            
                               
                            for i, molecule in enumerate(itertools.combinations(pos,2)):#compare each molecule of the same family
                                mol_a=molecule[0]
                                mol_b=molecule[1]
                                chi_a=mol_in_component[mol_a][3]
                                chi_b=mol_in_component[mol_b][3]
                                #print ("mol",mol_a, mol_b)
                                Fa=mol_in_component[mol_a][0]
                                Fb=mol_in_component[mol_b][0]
                                Ra=Rcomp[mol_a]
                                Sa=Scomp[mol_a]
                                Rb=Rcomp[mol_b]
                                Sb=Scomp[mol_b]
                                temp_chi=[]
                                #print("F", Fa)
                                #print("F", Fb)
                                
                                if Fa==Fb==Fx:

                                    #store chiral molecule id belonging to this chemical family
                                    if mol_a not in store[m]:
                                        store[m].append(mol_a)
                                        for c in chi_a:
                                            temp_chi.append(c[1])
                                        tchi.append(temp_chi)    
                                    if mol_b not in store[m]:
                                        temp_chi=[]
                                        store[m].append(mol_b)
                                        for c in chi_b:
                                            temp_chi.append(c[1])
                                        tchi.append(temp_chi)
                                    #print("tchi",tchi)        
                                    #print("store",store[m])
                                    
                                    mol_identical[m].append((mol_a, mol_b)) #save the pair of identical molecules 
                                    if chi_a==chi_b:#true if the label and the chirality are the same
                                        #in this case it means that both molecule have the same chirality
                                        mol_identical_same_chirality[m].append((mol_a,mol_b))#save the pair of molecues having the same chirality                
                                    else:#will check if it is enantiomer                   
                                        for c,d in zip(chi_a,chi_b): #compare the chirality of each atom in globality  
                                        #true if both molecule have different chirality    
                                            if c[1]+d[1]=='RS' or c[1]+d[1]=='SR':#couple of counter-enantiomer
                                               mol_identical_not_same_chirality[m].append((mol_a,mol_b))
                                            elif c[1]+d[1]=='RR' :#means couple of same enantiomer or stereoisomer
                                                mol_identical_same_chirality[m].append((mol_a,mol_b))
                                            elif c[1]+d[1]=='SS':
                                                mol_identical_same_chirality[m].append((mol_a,mol_b))

                                
                                mol_identical[m]=list(set(mol_identical[m]))
                                mol_identical_same_chirality[m]=list(set(mol_identical_same_chirality[m]))
                                mol_identical_not_same_chirality[m]=list(set(mol_identical_not_same_chirality[m]))
                                #check if the couple was classified in two subsets (same_chirality and not_same)
                                mol_duplicates=[[] for x in range(Nc)]
                                
                                mol_duplicates[m]=list(set(mol_identical_not_same_chirality[m]).intersection(set(mol_identical_same_chirality[m])))
                                if mol_duplicates[m]!=[]:
                                    mol_identical_same_chirality[m]=[x for x in mol_identical_same_chirality[m] if x not in mol_duplicates[m]]

                                mol_identical_couples_N[m]=len(mol_identical[m])
                                mol_same_chirality_couples_N[m]=len(mol_identical_same_chirality[m])
                                mol_not_same_chirality_couples_N[m]=len(mol_identical_not_same_chirality[m])
                                mol_not_identical_couples_N[m]=len(mol_not_identical[m])
                                
                            #Point group determination of the set of same molecule base on one of them     
                            compo[store[m][0]].remove_hydrogens()
                            N_point_group=len(compo[store[m][0]].atoms)
                            
                            if 3<N_point_group<125:#the molecule is limited to 125 atoms (H excludes)- you can change this number but the calculation time will strongly increase.
                                tempo=md.point_group_analysis(compo[store[m][0]])
                                point_group[m]=str(tempo[1])
                                point_group_of_chiral_mol.append(str(point_group[m]))
                                note_for_chiral_mol.append(str(tempo[2]))              
                            else:
                                warningc="Partially treated"
                                
                            mol_for_overlay=[compo[x] for x in store[m]]
                            
                            for mol_to_compare in itertools.combinations(mol_for_overlay,2):
                                mol_to_compare[0].assign_bond_types('Unknown')
                                mol_to_compare[1].assign_bond_types('Unknown')
                                mol_to_compare[0].add_hydrogens()
                                mol_to_compare[1].add_hydrogens()
                                try:
                                    rmsd_with_inversion[m].append(round(md.overlay_rmsds_and_transformation(mol_to_compare[0],mol_to_compare[1],atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[1],4))
                                    tanimoto_with_inversion[m].append(round(md.overlay_rmsds_and_transformation(mol_to_compare[0],mol_to_compare[1],atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[2],4))
                                except RuntimeError as exp:
                                    warningc='Problem in overlay calculation'
                                    
                            for mol_ab in mol_identical_same_chirality[m]:
                                #print(mol_ab)
                                mol_a=compo[mol_ab[0]]
                                mol_b=compo[mol_ab[1]]
                                mol_a.assign_bond_types('Unknown')
                                mol_b.assign_bond_types('Unknown')
                                mol_a.add_hydrogens()
                                mol_b.add_hydrogens()
                                try:
                                    rmsd_same_chirality[m].append(round(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[1],4)) 
                                    #print(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[3])
                                    tanimoto_same_chirality[m].append(round(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[2],4))   
                                except RuntimeError as exp:
                                    warningc='Problem in overlay calculation'
                            for mol_ab in mol_identical_not_same_chirality[m]:
                                #print(mol_ab)
                                mol_a=compo[mol_ab[0]]
                                mol_b=compo[mol_ab[1]]
                                mol_a.assign_bond_types('Unknown')
                                mol_b.assign_bond_types('Unknown')
                                mol_a.add_hydrogens()
                                mol_b.add_hydrogens()
                                try:
                                    rmsd_not_same_chirality[m].append(round(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[1],4))
                                    #print(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[3])    
                                    tanimoto_not_same_chirality[m].append(round(md.overlay_rmsds_and_transformation(mol_a,mol_b,atoms=None,invert=True, rotate_torsions=False, with_symmetry=True)[2],4))   
                                except RuntimeError as exp:
                                    warningc='Problem in overlay calculation'
                            
                            tchi_b=tchi
                            tchi=[''.join(x) for x in tchi]
                            chi_type[m]=tchi
                            #print("chi_type",chi_type[m])
                            chi_type_N[m]=len(list(set(chi_type[m])))
                           
                            for ichi,elem in enumerate(set(chi_type[m])):
                                chi_type_x[m].append((tchi.count(elem),elem))
                                #print("tchi",tchi.count(elem))
                            for el in tchi_b:
                                    for c_el,chi_el in enumerate(el):
                                        if chi_el == 'R':
                                            el[c_el] = 1
                                        elif chi_el == 'S':
                                            el[c_el]=-1
                            
                            chi_type_transformer[m]=tchi_b
                            AU_chi_type=[]
                            temp_chi=[]
                            
                            couple_chirality_m=[[] for x in range(len(list(itertools.combinations(list(set(chi_type[m])),2))))]
                        
                            if chi_type_N[m]>1:
                                for n, chir in enumerate(itertools.combinations(list(set(chi_type[m])),2)):#not used in the following
                                    temp_chi=[]
                                    for c,d in zip(chir[0],chir[1]):
                                    #for a in itertools.combinations(chir,2):
                                        if c+d=='RS' or c+d=='SR':#couple of counter-enantiomer
                                            temp_chi.append(0)
                                        if c+d=='RR' :#means couple of same enantiomer or stereoisomer
                                            temp_chi.append(2)                            
                                        if c+d=='SS':
                                            temp_chi.append(-2)
                 
                                    enantiomer_N=np.count_nonzero(temp_chi)
                                    #print(enantiomer_N)
                                    #Calculation of the relation between the two chiralities
                                    if enantiomer_N==0:
                                        couple_chirality_m[n].append('R')#for racemic couple
                                        #couple_chirality_m.insert(n,'R')#for racemic couple
                                    else:
                                        if Ra+Sa==Rb+Sb and enantiomer_N==len(temp_chi):                                        
                                            #couple_chirality_m.insert(n,'C')
                                            couple_chirality_m[n].append('C')#for chiral couple 
                                        else:
                                            #couple_chirality_m.insert(n,'S')
                                            couple_chirality_m[n].append('S')#for stereomer couple
                                
                                couple_chirality[m]=couple_chirality_m #couple chirality gave the relation (R, S or C)
                                
                               
                            else:
                                couple_chirality[m]='C'
                            couple_chirality_N[m]=len(set(map(tuple,couple_chirality[m])))
                            #print(couple_chirality_N[m])    
                         
                            if point_group[m] not in chiral_point_group :
                                AU_x[m]="MESO"
                            else:                               
                                if mol_not_same_chirality_couples_N[m]==0:#all enantiomer have the same chirality
                                        AU_x[m]="chiral"
                                        warning="Wa-could be Diast"
                                else:#at least 2 enantiomers of different chirality
                                    if mol_same_chirality_couples_N[m]==0:#no enantiomer of the same chirality 
                                            if couple_chirality_N[m]>2:
                                                AU_x[m]="diast"
                                                warning="contains Stereoisomer"
                                            else:
                                                if 'S' in chain(*couple_chirality[m]):
                                                    AU_x[m]="diast"
                                                    warning="DIAST-1, contains DIAST"
                                                else:
                                                    if chi_type_N[m]%2==0:
                                                        AU_x[m]="racemic"#could be either scalemic or stereoisomer
                                                        warning="RAC-1"
                                                    else:
                                                        AU_x[m]="scalemic"#could be either scalemic or stereoisomer
                                                        warning="SCAL-1"
                                    else:#contain 2 enantiomers of the same chirality  or stereoisomer or scalemic composition
                                        if couple_chirality_N[m]>2:
                                            
                                                AU_x[m]="diast"
                                                warning="diast-2 contains Stereoisomer"    
                                        else:  #chi_type_N<2 there is only 2 kind of stereomers
                                            
                                            if 'S' in chain(*couple_chirality[m]):
                                                AU_x[m]="diast"
                                                warning="DIAST-3"
                                            else:
                                                #print(chi_number[m], chi_type_x[m], chi_type_N[m])
                                                if chi_number[m]%2==0:#even number of chiral mol
                                                    #print(chi_type_x[0][0][0])
                                                    if chi_type_x[m][0][0]==chi_type_x[m][1][0]:
                                                        AU_x[m]="racemic"
                                                        warning="RAC-2"
                                                    else:
                                                        AU_x[m]="scalemic"
                                                        warning="scal-3a-attention could contain stereoisomer"
                                                else:
                                                    AU_x[m]="scalemic"
                                                    warning="scal-3b-attention could contain stereoisomer"

                
            #loop to determine and save the symbol element of atoms having chirality
            for n,chiral_atom_symb in enumerate(Elem):
                
                if chiral_atom_symb not in ChiAtom:
                    #print ("Elem",chiral_atom_symb)
                    ChiAtom.append(chiral_atom_symb)
                    #print("ChiAtom",ChiAtom,ChiAtom[0])
                    warningb = "contains following chiral atom(s)"+','.join(ChiAtom)
                
              
        if True in meso_check_c:
          AU_x.append("MESO")          
        AU=set((AU_x))#set the AU to reduce the AU chirality value to (at the maximum): [chiral, diast, scalemic, racemic ]
        
        #organized the rmsd values
        rmsd_with_inversion=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4), min(r or [0]), max(r or [0] )] for r in rmsd_with_inversion]
        rmsd_same_chirality=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4), min(r or [0]), max(r or [0] )] for r in rmsd_same_chirality]
        rmsd_not_same_chirality=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4), min(r or [0]), max(r or [0] )] for r in rmsd_not_same_chirality]
        
        tanimoto_with_inversion=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4),min(r or [0]), max(r or [0] )] for r in tanimoto_with_inversion]    
        tanimoto_same_chirality=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4),min(r or [0]), max(r or [0] )] for r in tanimoto_same_chirality]    
        tanimoto_not_same_chirality=[[r,'ND','ND','ND'] if len(r)<=1 else [round(np.mean(r),4),round(np.std(r),4),min(r or [0]), max(r or [0] )] for r in tanimoto_not_same_chirality]    

        #conditions to determine in the structure is chiral or not -     
        
        final_note=""
        if 'AU_x-error' in AU:
            final='ERROR'
            final_note="Error occurs in the determination of the AU chirality"
        elif 'Mixed' in AU:
            final='ERROR'
            final_note="AU contains mixed chirality type" 
        else:
            if not crystal.is_sohncke: 
                if "MESO" in AU_x:
                    final="MESO"
                else:
                    if "scalemic" in AU_x or "racemic" in AU_x or "chiral" in AU_x or "diast" in AU_x:
                        final="RACEMIC"
                     
            else:
                if "MESO" in AU_x:
                    final="MESO"
                elif "diast" in AU_x:
                    final="DIASTEREOMER"
                else:
                    if len(AU)==1:
                        if "racemic" in AU:
                            final="RACEMIC"
                            krypto="KRYPTORACEMIC"
                            if len(AU_x)==1:
                                final_note="Strict definition of kryptoracemate"
                            else:
                                final_note="Contains at least 2 different chemicals in racemic proportions"
                        elif "scalemic" in AU:
                            final="SCALEMIC"
                            krypto="KRYPTORACEMIC"
                            final_note="Unbalanced Kryptoracemate"
                            if len(AU_x)>1:
                                final_note="Contains 2 different chemicals in scalemic proportions"
                        elif "chiral" in AU:
                            final="CHIRAL"
                            if len(AU_x)==1:
                                final_note="Enantiopure"
                            else:
                               final_note="Contains at least 2 different chemicals in enantiopure proportions " 
                                            
                    elif len(AU)==2:
                        if "scalemic" in AU and "racemic" in AU:
                            final="RACEMIC"
                            krypto='KRYPTORACEMIC'
                            final_note="contains also an other chemical enantiomer in scalemic proportion"
                        elif "scalemic" in AU and "chiral" in AU:
                            final="SCALEMIC"
                            krypto='KRYPTORACEMIC'
                            final_note="Unbalanced Kryptoracemate -contains also an other enantiomer in enantiopure proportion" 
                        elif "chiral" in AU and "racemic" in AU:
                            final="RACEMIC"
                            krypto='KRYPTORACEMIC'
                            final_note='Contains also at least an other enantiomer in enantiopure proportion'
                        
                    elif len(AU)>2:
                        final_note='Contains at least 3 different chemicals in enantiopure, racemic and scalemic proportions'
                        final="Undetermined"
                  
        if chiral_mol_N!=cmax:
            final_note=final_note+' + achiral molecule'    
        total_time=time.time()-start_time+total_time
       #save the variables 
        self.out.write(','.join([
            '"%s"' % e.identifier,
            '"%s"' % final,
            '"%s"' % final_note,
            '"%s"' % krypto,
            '"%s"' % diast,
            '"%s"' % crystal.spacegroup_symbol,
            '"%s"' % SG,
            '"%s"' % crystal.is_sohncke,
            '"%s"' % e.has_disorder,
            '"%s"' % e.r_factor,
            '"%s"' % chiral_mol_N,
            '"%s"' % Nc,
            '"%s"' % chiral_atom_N,
            '"%s"' % sort(ChiAtom),
            '"%s"' % C_count,
            '"%s"' % H_count,
            '"%s"' % SumR,
            '"%s"' % SumS,
            '"%s"' % SumM,
            '"%s"' % chi_type_x,
            '"%s"' % chi_type_N,
            '"%s"' % chi_number,
            '"%s"' % AU_x,
            '"%s"' % list(set(point_group_of_chiral_mol)),
            '"%s"' % cmax,
            '"%s"' % crystal.z_prime,
            '"%s"' % crystal.z_value,
            '"%s"' % warning,
            '"%s"' % warningb,
            '"%s"' % warningc,
            '"%s"' % warningd,
            '"%s"' % crystal.cell_lengths[0],
            '"%s"' % crystal.cell_lengths[1],
            '"%s"' % crystal.cell_lengths[2],
            '"%s"' % crystal.cell_angles[0],
            '"%s"' % crystal.cell_angles[1],
            '"%s"' % crystal.cell_angles[2],
            '"%s"' % crystal.cell_volume,
            '"%s"' % crystal.calculated_density,            
            '"%s"' % e.formula,
            '"%s"' % e.chemical_name,
            '"%s"' % e.temperature,
            '"%s"' % e.pressure,
            '"%s"' % e.melting_point,
            '"%s"' % e.color,
            '"%s"' % e.polymorph,
            '"%s"' % e.phase_transition,
            '"%s"' % e.solvent,
            '"%s"' % e.remarks,
            '"%s"' % e.publication[0],
            '"%s"' % e.publication[2],
            '"%s"' % e.publication[4],
            '"%s"' % e.publication[1],
            '"%s"' % e.publication[3],
            '"%s"' % e.publication[5],
            '"%s"' % total_time,
            # '"%s"' % str(rmsd_with_inversion).translate(string.maketrans('',''),'[]\''),
            # '"%s"' % str(tanimoto_with_inversion).translate(string.maketrans('',''),'[]\''),
            # '"%s"' % str(rmsd_same_chirality).translate(string.maketrans('',''),'[]\''),
            # '"%s"' % str(tanimoto_same_chirality).translate(string.maketrans('',''),'[]\''),
            # '"%s"' % str(rmsd_not_same_chirality).translate(string.maketrans('',''),'[]\''),
            # '"%s"' % str(tanimoto_not_same_chirality).translate(string.maketrans('',''),'[]\''),
            
        ]))
        self.out.write('\n')
        




class Arguments(argparse.ArgumentParser):
    '''Options for the program'''

    def __init__(self):
        argparse.ArgumentParser.__init__(self, description=__doc__)
        self.add_argument(
            'input_file',
            help='Location of a gcd file of required refcodes'
        )
        self.add_argument(
            '-o', '--output', default='stdout',
            help='output file [stdout]'
        )
        self.add_argument(
            '-f', '--format', default='csv', choices=['csv', 'html'],
            help='output format [csv]'
        )
        self.args = self.parse_args()


class OsLineEndDialect(csv.excel):
    """An os-dependent dialect that will write the correct line endings
    to the CSV file.
    """
    lineterminator = os.linesep


if __name__ == '__main__':
    args = Arguments()
    if args.args.format == 'csv':
        if args.args.output == 'stdout':
            if six.PY2:
                out = codecs.getwriter('utf8')(sys.stdout)
            else:
                out = sys.stdout
        else:
            out = codecs.open(args.args.output, 'w', encoding='utf-8')
    else:
        if args.args.output == 'stdout':
            if six.PY2:
                out = codecs.getwriter('utf8')(sys.stdout)
            else:
                out = sys.stdout
        else:
            out = codecs.open(args.args.output, 'w', encoding='utf8')
    w = Writer(args.args.input_file, out, args.args.format)
    if args.args.format != 'csv':
        out.close()

