from enum import Enum


class Info(Enum):
  IDENTIFIER = "Identifier"
  CLASS = "Class"
  NOTE = "Note"
  KRYPTORACEMIC = "Kryptoracemic?"
  DIAST = "Diast?"
  SPACE_GP_SYMBOL = "Space Gp. Symbol"
  SPACE_GP_NUMBER = "Space Gp. Number"
  IS_SOHNCKE = "Is Sohncke?"
  HAS_DISORDER = "Has Disorder?"
  OCCUPANCY = "Occupancy"
  R_FACTOR = "R-factor"
  NUMBER_OF_CHIRAL_RESD = "Number of chiral resd"
  NUMBER_OF_CHIRAL_FAMILIES = "Number of chiral families"
  NUMBER_OF_CHIRAL_CENTER = "Number of chiral center"
  CHIRAL_ATOM_SYMB = "Chiral Atom Symb"
  NUMBER_OF_CARBON_CHIRAL_ATOM = "Number of Carbon Chiral Atom"
  NUMBER_OF_CHIRAL_CENTER_HAVING_H = "Number of Chiral Center having H"
  R = "R"
  S = "S"
  M = "M"
  NUMBER_AND_TYPE_OF_CHIRAL_CONFIGURATION = "Number and type of chiral configuration"
  NUMBER_OF_CHIRAL_CONFIGURATION = "Number of chiral configuration"
  NUMBER_OF_MOLECULE_IN_FAMILY = "Number of molecule in Family"
  AU_CHIRALITY = "AU_chirality"
  POINT_GROUP_OF_CHIRAL_MOL = "point_group_of_chiral_mol"
  UNIQUE_CHEMICAL_UNITS = "Unique Chemical Units"
  Z_PRIME = "Z Prime"
  Z_VALUE = "Z Value"
  NOTE1 = "Note1"
  NOTE2 = "Note2"
  NOTE3 = "Note3"
  A = "a"
  B = "b"
  C = "c"
  ALPHA = "Alpha"
  BETA = "Beta"
  GAMMA = "Gamma"
  CELL_VOLUME = "Cell Volume"
  CALC_DENSITY = "Calc. Density"
  FORMULA = "formula"
  COMPOUND_NAME = "Compound Name"
  STUDY_TEMP = "Study Temp."
  PRESSURE = "pressure"
  MELTING_POINT = "melting_point"
  COLOR = "color"
  POLYMORPH = "polymorph"
  PHASE_TRANSITIONS = "phase_transitions"
  RECRYSTALLISATION_SOLVENT = "recrystallisation_solvent"
  REMARKS = "remarks"
  AUTHORS_COMMA_DELIMITED = "authors_comma_delimited"
  VOLUME = "volume"
  PAGE = "page"
  JOURNAL = "journal"
  PUBLICATION_YEAR = "Publication Year"
  DOI = "doi"
  TIME_IN_SECONDS = "Time (in seconds)"
  PSEUDO_SYM_1_TF = "Pseudo Symétrie : 0%  (torsion = False)"
  PSEUDO_SYM_2_TF = "Pseudo Symétrie : 5%  (torsion = False)"
  PSEUDO_SYM_3_TF = "Pseudo Symétrie : 10% (torsion = False)"
  PSEUDO_SYM_4_TF = "Pseudo Symétrie : 15% (torsion = False)"
  PSEUDO_SYM_5_TF = "Pseudo Symétrie : 20% (torsion = False)"
  PSEUDO_SYM_1_TT = "Pseudo Symétrie : 0%  (torsion = True)"
  PSEUDO_SYM_2_TT = "Pseudo Symétrie : 5%  (torsion = True)"
  PSEUDO_SYM_3_TT = "Pseudo Symétrie : 10% (torsion = True)"
  PSEUDO_SYM_4_TT = "Pseudo Symétrie : 15% (torsion = True)"
  PSEUDO_SYM_5_TT = "Pseudo Symétrie : 20% (torsion = True)"
  RMSD = "rmsd"
  RMSD_SAME_CHIRALITY = "rmsd_same_chirality"
  RMSD_NOT_SAME_CHIRALITY = "rmsd_not_same_chirality"
  TANIMOTO = "Tanimoto"
  TANIMOTO_SAME_CHIRLITY = "tanimoto_same_chirality"
  TANIMOTO_NOT_SAME_CHIRALITY = "tanimoto_not_same_chirality"

def getSizeOfAllInfo(enum):
  l = list(enum)
  r = len(l)
  for i in range(0, len(l)):
    r += len(l[i].value)
  return r

def getAllValueInfo(enum):
  l = list(enum)
  r = []
  for s in l:
    r.append(s.value)
  return r
